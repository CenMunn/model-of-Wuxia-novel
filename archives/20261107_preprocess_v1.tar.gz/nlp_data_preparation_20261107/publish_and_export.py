from pathlib import Path
import subprocess,sys,json,traceback
HERE=Path(__file__).resolve().parent
def main():
    final='/home/xh/ww/nlp/shared/data/versions/corpus_v1_20261107'
    with (HERE/'publication.log').open('w',encoding='utf-8') as log:
        try:
            for args in [[str(HERE/'finalize_version.py')],[str(HERE/'verify_corpus.py'),final],[str(HERE/'build_backup.py')]]:
                subprocess.run([sys.executable,'-u',*args],cwd=HERE,stdout=log,stderr=subprocess.STDOUT,check=True)
            (HERE/'export_state.json').write_text(json.dumps(dict(phase='export_complete',server_full_verification=True),indent=2),encoding='utf-8')
        except Exception:
            log.write(traceback.format_exc());log.flush()
            (HERE/'export_state.json').write_text(json.dumps(dict(phase='failed',log=str(HERE/'publication.log')),indent=2),encoding='utf-8');raise
if __name__=='__main__':main()
