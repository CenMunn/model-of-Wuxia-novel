from pathlib import Path
import unittest,json,copy
from evidence_assertions import verify_repair_evidence,verify_subset
HERE=Path(__file__).resolve().parent

class AcceptanceGates(unittest.TestCase):
    def test_unwitnessed_repair_cannot_pass_by_merely_removing_pua(self):
        repairs=json.loads((HERE/'repairs.json').read_text(encoding='utf-8'))['repairs']
        for r in repairs:
            witness=(HERE/'witnesses'/r['source']['text_file']).read_text(encoding='utf-8')
            self.assertTrue(verify_repair_evidence(r,witness))
            wrong=copy.deepcopy(r);wrong['after']+='这段没有原文依据。'
            with self.assertRaises(AssertionError):verify_repair_evidence(wrong,witness)

    def test_training_subset_rejects_altered_body_and_duplicate_ids(self):
        all_samples=[dict(sample_id='a',source_group='jinyong',source='原来的前文',target='原来的后文'),
                     dict(sample_id='b',source_group='supplementary',source='另一段',target='后续')]
        subset=[copy.deepcopy(all_samples[0])]
        self.assertTrue(verify_subset(subset,all_samples,'jinyong'))
        altered=copy.deepcopy(subset);altered[0]['target']='另造的正文'
        with self.assertRaises(AssertionError):verify_subset(altered,all_samples,'jinyong')
        with self.assertRaises(AssertionError):verify_subset(subset+subset,all_samples,'jinyong')

if __name__=='__main__':unittest.main()
