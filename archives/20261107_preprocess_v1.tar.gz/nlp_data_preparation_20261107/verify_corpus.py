"""Independent full-data contract verification, including every training example."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,hashlib,json,re,time
from pipeline_core import is_pua,find_exact_edges
from evidence_assertions import verify_repair_evidence,verify_subset

def load_rows(path):
    with path.open(encoding='utf-8') as f:return [json.loads(line) for line in f if line.strip()]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('version');parser.add_argument('--project-root');args=parser.parse_args()
    root=Path(args.version);start=time.monotonic()
    config=json.loads((root/'config.json').read_text(encoding='utf-8'));project=Path(args.project_root or config['project_root'])
    rawmanifest=json.loads((root/'raw_manifest.json').read_text(encoding='utf-8'))
    raw={};originals=[]
    for b in rawmanifest['books']:
        path=project/b['relative_path'];assert digest(path)==b['sha256'],path
        raw[b['book_id']]=path.read_bytes().decode(b['encoding'],errors='strict').splitlines();originals.append(str(path))
    archive=project/rawmanifest['archive']['relative_path'];assert digest(archive)==rawmanifest['archive']['sha256']
    ps=load_rows(root/'clean/paragraphs.jsonl');cs=load_rows(root/'clean/chapters.jsonl');segs=load_rows(root/'clean/segments.jsonl')
    pm={p['paragraph_id']:p for p in ps};cm={c['chapter_id']:c for c in cs};assert len(pm)==len(ps) and len(cm)==len(cs)
    rep=load_rows(root/'records/repairs.jsonl');qs=load_rows(root/'records/quarantine.jsonl');bounds=load_rows(root/'records/boundaries.jsonl')
    rm={r['repair_id']:r for r in rep};qm={q['quarantine_id']:q for q in qs}
    sources=json.loads((root/'records/witness_sources.json').read_text(encoding='utf-8'))
    source_by_key={(s['book_id'],s['chapter']):s for s in sources}
    witness_root=Path(__file__).resolve().parent/'witnesses'
    for s in sources:
        assert digest(witness_root/s['text_file'])==s['text_sha256']
        assert digest(witness_root/(Path(s['text_file']).stem+'.html'))==s['html_sha256']
    for r in rep:
        source=r['source'];assert source==source_by_key[(source['book_id'],source['chapter'])]
        verify_repair_evidence(r,(witness_root/source['text_file']).read_text(encoding='utf-8'))
    assert len(raw)==17
    pua_raw=sum(sum(map(is_pua,line)) for ls in raw.values() for line in ls)
    assert pua_raw==sum(r['original_pua_occurrences'] for r in rep)+sum(q['original_pua_occurrences'] for q in qs)==196
    for r in rep:assert raw[r['book_id']][r['line']-1]==r['before'];assert not any(map(is_pua,r['after']))
    for q in qs:
        assert raw[q['book_id']][q['line']-1]==q['text']
        assert any(b.get('quarantine_id')==q['quarantine_id'] and b['kind']=='quarantine_gap' for b in bounds)
        assert not any(p['book_id']==q['book_id'] and p['original_line_start']==q['line'] for p in ps)
    for p in ps:
        assert p['text'] and not any(map(is_pua,p['text'])) and '\ufffd' not in p['text']
        assert not any(ord(c)<32 for c in p['text'])
        assert '以下缺失' not in p['text']
        assert p['split']==cm[p['chapter_id']]['split']
        if p['text_origin']=='original':
            original=raw[p['book_id']][p['original_line_start']-1]
            assert original[p['original_char_start']:p['original_char_end']]==p['text']
        else:assert p['text'] in rm[p['repair_id']]['after'].split('\n\n') or p['text'] in [s.strip(' \t\u3000\r\n') for s in rm[p['repair_id']]['after'].split('\n\n')]
    for c in cs:
        assert c['characters']==sum(len(pm[i]['text']) for i in c['paragraph_ids'])
        assert all(pm[i]['chapter_id']==c['chapter_id'] for i in c['paragraph_ids'])
        assert [b['paragraph_id'] for b in c['blocks'] if b['kind']=='paragraph']==c['paragraph_ids']
    for spec in config['books']:
        chapters=[c for c in cs if c['book_id']==spec['book_id']]
        assert len(chapters)==spec['expected_chapters']
        numbers=[c['number'] for c in chapters if c['number'] not in (0,None)]
        if numbers:assert numbers==list(range(1,max(numbers)+1))
    assert sum(c['is_narrative_prologue'] for c in cs)==1
    assert sum(not c['has_original_heading'] for c in cs)==3
    # Each physical source line must have exactly one accounted category.
    classes=load_rows(root/'records/line_classification.jsonl');bybook=defaultdict(list)
    for r in classes:bybook[r['book_id']].append(r)
    line_categories={}
    for bid,rs in bybook.items():
        position=1
        categories=[]
        for r in rs:
            assert r['start_line']==position;position=r['end_line']+1
            categories.extend([r['category']]*(r['end_line']-r['start_line']+1))
        assert position==len(raw[bid])+1
        line_categories[bid]=categories
    for ex in load_rows(root/'records/excluded_blocks.jsonl'):
        assert '\n'.join(raw[ex['book_id']][ex['original_line_start']-1:ex['original_line_end']])==ex['original_text']
    for phrase in ['千捧','井无','。。','／']:
        original_count=sum(line.count(phrase) for b,ls in raw.items() for n,line in enumerate(ls,1)
            if line_categories[b][n-1]=='story')
        unchanged_count=sum(p['text'].count(phrase) for p in ps if p['text_origin']=='original')
        assert original_count==unchanged_count,(phrase,original_count,unchanged_count)
    all_samples=[];sample_counts={};subsets={}
    for split in ['train','validation']:
        samples=load_rows(root/f'samples/{split}.jsonl');sample_counts[split]=len(samples);all_samples.extend(samples)
        assert len({s['sample_id'] for s in samples})==len(samples)
        for sample in samples:
            src=sample['source_paragraph_ids'];tgt=sample['target_paragraph_ids'];ids=src+tgt
            assert src and tgt
            paragraphs=[pm[i] for i in ids]
            assert len({p['book_id'] for p in paragraphs})==len({p['chapter_id'] for p in paragraphs})==len({p['segment_id'] for p in paragraphs})==len({p['scene_id'] for p in paragraphs})==1
            assert {p['split'] for p in paragraphs}=={split}
            assert sample['source']=='\n\n'.join(pm[i]['text'] for i in src)
            assert sample['target']=='\n\n'.join(pm[i]['text'] for i in tgt)
            orders=[p['order'] for p in paragraphs];assert orders==list(range(orders[0],orders[-1]+1))
            assert config['samples']['min_source_chars']<=len(sample['source'])<=config['samples']['max_source_chars']
            assert config['samples']['min_target_chars']<=len(sample['target'])<=config['samples']['max_target_chars']
        combined=set()
        for group in ['jinyong','supplementary']:
            subset=load_rows(root/f'samples/{split}_{group}.jsonl')
            verify_subset(subset,samples,group)
            assert {s['sample_id'] for s in subset}=={s['sample_id'] for s in samples if s['source_group']==group}
            assert not combined&{s['sample_id'] for s in subset};combined.update(s['sample_id'] for s in subset)
            subsets[split+'_'+group]=len(subset)
        assert combined=={s['sample_id'] for s in samples}
    assert len({s['sample_id'] for s in all_samples})==len(all_samples)
    # Independently scan actual clean segment text after the split is materialized.
    for s in segs:
        assert s['text']=='\n\n'.join(pm[i]['text'] for i in s['paragraph_ids'])
        assert s['split']==cm[s['chapter_id']]['split']
    overlaps=find_exact_edges(segs,config['dedup']['exact_substring_min_chars'])
    assert not [r for r in overlaps if cm[r['chapter_a']]['split']!=cm[r['chapter_b']]['split']]
    for name in ['exact_substrings','exact_paragraphs','near_paragraphs']:
        for row in load_rows(root/f'dedup/{name}.jsonl'):
            assert cm[row['chapter_a']]['split']==cm[row['chapter_b']]['split']
    for g in load_rows(root/'dedup/chapter_components.jsonl'):
        assert len({cm[c]['split'] for c in g['chapter_ids']})==1
    training=set(c for p in ps if p['split']=='train' for c in p['text'])|{'\n'}
    vocab=json.loads((root/'vocab/char_all_training.json').read_text(encoding='utf-8'))
    assert len(vocab['tokens'])==len(set(vocab['tokens']))
    assert set(vocab['tokens'][4:])==training
    heldout=Counter(c for p in ps if p['split']=='validation' for c in p['text'])
    unknown=sum(n for c,n in heldout.items() if c not in training)
    fraction=sum(c['characters'] for c in cs if c['split']=='validation')/sum(c['characters'] for c in cs)
    assert .03<=fraction<=.07,fraction
    # Final raw-byte verification after reading and processing the entire version.
    for b in rawmanifest['books']:assert digest(project/b['relative_path'])==b['sha256']
    assert digest(archive)==rawmanifest['archive']['sha256']
    report=dict(passed=True,raw_books_sha256_verified=17,archive_sha256_verified=True,
        chapters_verified=len(cs),paragraphs_verified=len(ps),samples_verified=len(all_samples),sample_counts=sample_counts,
        sample_subsets=subsets,all_original_lines_classified=True,utf8_strict=True,all_pua_issues_accounted=True,
        pua_original=pua_raw,pua_repaired=sum(r['original_pua_occurrences'] for r in rep),pua_quarantined=sum(q['original_pua_occurrences'] for q in qs),
        quarantined_paragraphs=len(qs),cross_gap_samples=0,cross_chapter_samples=0,cross_split_duplicate_groups=0,
        cross_split_exact_substrings_at_least_128_nonwhitespace_characters=0,
        near_duplicate_scope='MinHash LSH candidate paragraphs, verified char-5 Jaccard >= .85; not exhaustive semantic deduplication',
        repair_records_replayed_against_cached_source=len(rep),all_split_subset_objects_verified=True,
        vocabulary_uses_validation=False,validation_unknown_char_occurrences=unknown,validation_unknown_char_fraction=unknown/sum(heldout.values()),
        validation_character_fraction=fraction,no_independent_source_test_set=True,elapsed_seconds=round(time.monotonic()-start,2))
    (root/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
