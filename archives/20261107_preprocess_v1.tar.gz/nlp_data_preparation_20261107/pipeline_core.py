"""Core contracts for a provenance-preserving literary corpus pipeline."""
from collections import defaultdict,deque
import hashlib,itertools

def layout_text(text):
    return text.strip(' \t\u3000\r\n')

def is_pua(char):
    n=ord(char)
    return 0xe000<=n<=0xf8ff or 0xf0000<=n<=0xffffd or 0x100000<=n<=0x10fffd

def decode_strict(data,encoding):return data.decode(encoding,errors='strict')

def chapter_number(s):
    digits={c:i for i,c in enumerate('零一二三四五六七八九')}
    digits.update({'〇':0,'○':0,'两':2})
    if s.isascii() and s.isdecimal():return int(s)
    if not any(c in s for c in '十百千'):return int(''.join(str(digits[c]) for c in s))
    total=current=0
    for c in s:
        if c in digits:current=digits[c]
        else:total+=(current or 1)*{'十':10,'百':100,'千':1000}[c];current=0
    return total+current

def chinese_number(n):
    digits='零一二三四五六七八九'
    if n<10:return digits[n]
    if n<100:return ('' if n//10==1 else digits[n//10])+'十'+(digits[n%10] if n%10 else '')
    if n<1000:
        return digits[n//100]+'百'+(('零'+digits[n%10]) if 0<n%100<10 else ('一'+chinese_number(n%100) if 10<=n%100<20 else chinese_number(n%100)) if n%100 else '')
    raise ValueError(n)

def make_samples(paragraphs,limits):
    """Whole adjacent paragraphs; no truncation, skipped interior paragraphs, or gap joins."""
    result=[]
    key=lambda p:(p['book_id'],p['chapter_id'],p['segment_id'],p['scene_id'],p['split'])
    for group_key,group_iter in itertools.groupby(paragraphs,key):
        group=list(group_iter)
        for boundary in range(1,len(group)):
            source=[];chars=0
            for p in reversed(group[:boundary]):
                proposed=len(p['text'])+(2 if source else 0)
                if chars+proposed>limits['max_source_chars']:break
                source.insert(0,p);chars+=proposed
                if chars>=limits['source_goal_chars']:break
            if chars<limits['min_source_chars']:continue
            target=[];chars=0
            for p in group[boundary:]:
                proposed=len(p['text'])+(2 if target else 0)
                if chars+proposed>limits['max_target_chars']:break
                target.append(p);chars+=proposed
                if chars>=limits['target_goal_chars']:break
            if chars<limits['min_target_chars']:continue
            result.append({'sample_id':group[boundary]['paragraph_id']+'-next',
                'book_id':group_key[0],'chapter_id':group_key[1],'segment_id':group_key[2],
                'scene_id':group_key[3],'split':group_key[4],
                'source_group':group[0].get('source_group'),
                'source_paragraph_ids':[p['paragraph_id'] for p in source],
                'target_paragraph_ids':[p['paragraph_id'] for p in target],
                'source':'\n\n'.join(p['text'] for p in source),
                'target':'\n\n'.join(p['text'] for p in target)})
    return result

def connected_groups(ids,edges):
    parent={i:i for i in ids}
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for a,b in edges:
        ra,rb=find(a),find(b)
        if ra!=rb:parent[max(ra,rb)]=min(ra,rb)
    groups=defaultdict(list)
    for i in ids:groups[find(i)].append(i)
    return {k:sorted(v) for k,v in groups.items()}

def assign_splits(chapters,edges,seed,target):
    """Greedy character-balanced whole-chapter selection with duplicate components intact."""
    lookup={c['chapter_id']:c for c in chapters}
    groups=connected_groups(lookup,edges)
    totals=defaultdict(int);counts=defaultdict(int)
    for c in chapters:totals[c['book_id']]+=c['characters'];counts[c['book_id']]+=1
    selected=defaultdict(int);selected_counts=defaultdict(int);split={i:'train' for i in lookup}
    pending=set(groups)
    while pending:
        candidates=[]
        for gid in pending:
            amounts=defaultdict(int);ns=defaultdict(int)
            for i in groups[gid]:
                c=lookup[i];amounts[c['book_id']]+=c['characters'];ns[c['book_id']]+=1
            if any(selected_counts[b]+ns[b]>=counts[b] for b in amounts):continue
            improvement=sum(abs(selected[b]-totals[b]*target)-abs(selected[b]+n-totals[b]*target) for b,n in amounts.items())
            if improvement>0:
                tie=hashlib.sha256(f'{seed}:{gid}'.encode()).hexdigest()
                candidates.append((improvement,tie,gid,amounts,ns))
        if not candidates:break
        _,_,gid,amounts,ns=max(candidates,key=lambda x:(x[0],x[1]))
        for i in groups[gid]:split[i]='validation'
        for b,n in amounts.items():selected[b]+=n;selected_counts[b]+=ns[b]
        pending.remove(gid)
    return split

def fingerprint_text(text):return ''.join(c for c in text if not c.isspace())

def winnow(text,k=32,window=64):
    """Winnowing: every shared span >= k+window-1 has a common candidate fingerprint."""
    if len(text)<k:return
    mask=(1<<64)-1;base=257;power=pow(base,k-1,1<<64);h=0
    for c in text[:k]:h=((h*base)+ord(c)+1)&mask
    minima=deque();last=None
    for i in range(len(text)-k+1):
        if i:h=(((h-(ord(text[i-1])+1)*power)&mask)*base+ord(text[i+k-1])+1)&mask
        while minima and minima[-1][1]>=h:minima.pop()
        minima.append((i,h))
        while minima[0][0]<=i-window:minima.popleft()
        if i>=min(window,len(text)-k+1)-1 and minima[0][0]!=last:
            last=minima[0][0];yield minima[0][1],last

def find_exact_edges(segments,minimum=128):
    normalized=[fingerprint_text(s['text']) for s in segments]
    inverted=defaultdict(list);done=set();rows=[]
    for i,(segment,text) in enumerate(zip(segments,normalized)):
        if len(text)<minimum:continue
        for h,pos in winnow(text):
            for j,otherpos in inverted[h]:
                other=segments[j]
                if segment['chapter_id']==other['chapter_id']:continue
                pair=tuple(sorted((segment['chapter_id'],other['chapter_id'])))
                if pair in done:continue
                previous=normalized[j]
                if text[pos:pos+32]!=previous[otherpos:otherpos+32]:continue
                left=0
                while pos-left>0 and otherpos-left>0 and text[pos-left-1]==previous[otherpos-left-1]:left+=1
                right=32
                while pos+right<len(text) and otherpos+right<len(previous) and text[pos+right]==previous[otherpos+right]:right+=1
                if left+right<minimum:continue
                done.add(pair)
                rows.append({'chapter_a':other['chapter_id'],'chapter_b':segment['chapter_id'],
                    'segment_a':other['segment_id'],'segment_b':segment['segment_id'],
                    'offset_a':otherpos-left,'offset_b':pos-left,'length':left+right,
                    'type':'exact_nonwhitespace_substring','excerpt':text[pos-left:pos+min(right,180)]})
            inverted[h].append((i,pos))
    return rows
