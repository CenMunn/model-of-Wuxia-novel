"""Candidate MinHash LSH, followed by exact character 5-gram Jaccard verification."""
import hashlib,zlib
from collections import defaultdict
import numpy as np

def normalized(text):return ''.join(c for c in text if c.isalnum())
def shingles(text,n=5):return {text[i:i+n] for i in range(len(text)-n+1)}

def find_near_pairs(paragraphs,threshold=.85,min_chars=100,min_ratio=.8):
    rng=np.random.default_rng(20261107)
    a=rng.integers(1,2**63,size=64,dtype=np.uint64)*np.uint64(2)+np.uint64(1)
    b=rng.integers(0,2**64-1,size=64,dtype=np.uint64)
    index=defaultdict(list);texts=[];eligible=[];rows=[];checked=set()
    for paragraph in paragraphs:
        text=normalized(paragraph['text'])
        if len(text)<min_chars:continue
        grams=shingles(text)
        hashes=np.array([zlib.crc32(g.encode('utf-8')) for g in grams],dtype=np.uint64)
        # Arithmetic in the uint64 ring is deliberate; signatures are reproducible.
        signature=(hashes[:,None]*a[None,:]+b[None,:]).min(axis=0)
        keys=[(band,signature[band*4:band*4+4].tobytes()) for band in range(16)]
        candidates={j for key in keys for j in index[key]}
        i=len(texts)
        for j in candidates:
            previous=eligible[j]
            if paragraph['chapter_id']==previous['chapter_id']:continue
            pair=tuple(sorted((paragraph['paragraph_id'],previous['paragraph_id'])))
            if pair in checked:continue
            checked.add(pair)
            other=texts[j]
            if min(len(text),len(other))/max(len(text),len(other))<min_ratio:continue
            if text==other:continue
            gs=shingles(other);score=len(grams&gs)/len(grams|gs)
            if score>=threshold:
                rows.append(dict(type='near_paragraph_char5_jaccard',chapter_a=previous['chapter_id'],
                    chapter_b=paragraph['chapter_id'],paragraph_a=previous['paragraph_id'],
                    paragraph_b=paragraph['paragraph_id'],jaccard=score,length_a=len(other),length_b=len(text)))
        texts.append(text);eligible.append(paragraph)
        for key in keys:index[key].append(i)
    return rows
