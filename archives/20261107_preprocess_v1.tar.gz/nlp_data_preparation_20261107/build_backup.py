"""Export a checked, self-contained corpus/tools snapshot without credentials."""
from pathlib import Path
import json,hashlib,tarfile,io,subprocess,time
HERE=Path(__file__).resolve().parent
BASE=Path('/home/xh/ww')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    config=json.loads((HERE/'config.json').read_text(encoding='utf-8'))
    version=Path(config['output_root']);project=Path(config['project_root'])
    verified=json.loads((version/'verification.json').read_text(encoding='utf-8'))
    ready=json.loads((version/'manifest.json').read_text(encoding='utf-8'))
    assert verified['passed'] and ready['training_ready']
    assert verified['repair_records_replayed_against_cached_source']==33
    assert verified['all_split_subset_objects_verified']
    export=HERE/'exports';export.mkdir(exist_ok=True)
    name='20261107_preprocess_v1';archive=export/(name+'.tar.gz');assert not archive.exists()
    files=[]
    for base in [version,project/'shared/data/raw',HERE]:
        for p in sorted(base.rglob('*')):
            if base==HERE and ('exports' in p.relative_to(HERE).parts or '__pycache__' in p.relative_to(HERE).parts):continue
            if base==HERE and p.name in ['publication.log','launcher.log','export_state.json']:continue
            if p.is_symlink():raise ValueError('Unexpected symlink: '+str(p))
            if p.is_file():
                assert p.resolve().is_relative_to(BASE)
                files.append(p)
    pointer=version.parent/'current.json';files.append(pointer)
    assert len(files)==len(set(files))
    rows=[dict(relative_path=p.relative_to(BASE).as_posix(),bytes=p.stat().st_size,sha256=digest(p)) for p in files]
    status=subprocess.run(['git','-C',str(project/'main'),'status','--short'],capture_output=True,text=True,check=True).stdout
    head=subprocess.run(['git','-C',str(project/'main'),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
    manifest=dict(snapshot_id=name,scope='all canonical raw corpus, complete processed version, external preparation tools/evidence/logs; existing main checkout unchanged',
        files=rows,total_bytes=sum(r['bytes'] for r in rows),file_count=len(rows),git_main_head=head,git_main_status=status,
        version_id=config['version_id'],training_started=False,server_verification=verified)
    data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
        for p in files:tar.add(p,arcname=p.relative_to(BASE).as_posix(),recursive=False)
        item=tarfile.TarInfo('snapshot_manifest.json');item.size=len(data);tar.addfile(item,io.BytesIO(data))
    for p,row in zip(files,rows):assert digest(p)==row['sha256'],'Source changed during backup: '+str(p)
    result=dict(archive=str(archive),archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,
        source_manifest_sha256=hashlib.sha256(data).hexdigest(),file_count=len(rows),uncompressed_bytes=manifest['total_bytes'],
        source_files_verified_after_archive=True,git_main_head=head,git_main_status=status)
    (export/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (export/(name+'.manifest.json')).write_bytes(data)
    print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
