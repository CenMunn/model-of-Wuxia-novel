"""Run preprocessing and verification; logs stay outside the shared project."""
from pathlib import Path
import json,subprocess,sys,os,traceback,hashlib
HERE=Path(__file__).resolve().parent
CONFIG=json.loads((HERE/'config.json').read_text(encoding='utf-8'))
def state(phase,**kwargs):
    (HERE/'run_state.json').write_text(json.dumps(dict(phase=phase,**kwargs),ensure_ascii=False,indent=2),encoding='utf-8')
def main():
    final=Path(CONFIG['output_root']);stage=final.with_name(final.name+'.staging')
    state('starting')
    with (HERE/'execution.log').open('w',encoding='utf-8') as log:
        try:
            for phase,args in [('unit_tests',['-m','unittest','discover','-s',str(HERE),'-p','test_*.py','-v']),
                ('verify_witness_repairs',[str(HERE/'build_repair_proposals.py')]),
                ('build_corpus',[str(HERE/'corpus_pipeline.py')]),
                ('verify_all_records_and_samples',[str(HERE/'verify_corpus.py'),str(stage)])]:
                state(phase);log.write('\nPHASE '+phase+'\n');log.flush()
                subprocess.run([sys.executable,'-u',*args],cwd=HERE,stdout=log,stderr=subprocess.STDOUT,check=True,
                    env={**os.environ,'PYTHONIOENCODING':'utf-8'})
            state('verified_staging',staging_path=str(stage),finalized=False)
        except Exception:
            log.write(traceback.format_exc());log.flush();state('failed',log=str(HERE/'execution.log'));raise
if __name__=='__main__':main()
