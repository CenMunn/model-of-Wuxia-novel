import unittest,json,hashlib
from pathlib import Path
import pipeline_core as core

class CorpusContract(unittest.TestCase):
    def test_cached_witness_sha256_matches_actual_file_bytes(self):
        root=Path(__file__).resolve().parent/'witnesses'
        manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
        for item in manifest:
            self.assertEqual(hashlib.sha256((root/item['text_file']).read_bytes()).hexdigest(),item['text_sha256'],item['text_file'])

    def test_near_duplicate_scan_recognizes_small_edits_but_not_short_cliches(self):
        from near_duplicates import find_near_pairs
        text=''.join(chr(0x4e00+i) for i in range(220))
        rows=[dict(paragraph_id='a',chapter_id='c1',text=text),
              dict(paragraph_id='b',chapter_id='c2',text=text[:100]+'剑'+text[101:]),
              dict(paragraph_id='c',chapter_id='c3',text='兄弟，请坐。')]
        matches=find_near_pairs(rows)
        self.assertEqual(len(matches),1)
        self.assertGreaterEqual(matches[0]['jaccard'],.85)

    def test_continuation_does_not_cross_quarantine_or_chapter(self):
        paragraphs=[]
        for chapter,segment in [('c1','a'),('c1','b'),('c2','c')]:
            for n in range(3):
                paragraphs.append(dict(paragraph_id=f'{segment}{n}',text=f'侠客{segment}{n}。',book_id='b',
                    chapter_id=chapter,segment_id=segment,scene_id=segment,split='train',order=len(paragraphs)))
        samples=core.make_samples(paragraphs,dict(max_source_chars=32,max_target_chars=16,
            source_goal_chars=1,target_goal_chars=1,min_source_chars=1,min_target_chars=1))
        self.assertEqual(len(samples),6)
        lookup={p['paragraph_id']:p for p in paragraphs}
        for s in samples:
            ids=s['source_paragraph_ids']+s['target_paragraph_ids']
            self.assertEqual(len({lookup[i]['segment_id'] for i in ids}),1)
            self.assertEqual(len({lookup[i]['chapter_id'] for i in ids}),1)
            self.assertEqual(s['source'],'\n\n'.join(lookup[i]['text'] for i in s['source_paragraph_ids']))
            self.assertEqual(s['target'],'\n\n'.join(lookup[i]['text'] for i in s['target_paragraph_ids']))
            orders=[lookup[i]['order'] for i in ids]
            self.assertEqual(orders,list(range(orders[0],orders[-1]+1)))

    def test_oversize_paragraph_is_never_silently_skipped_to_join_neighbors(self):
        ps=[dict(paragraph_id=str(i),text=t,book_id='b',chapter_id='c',segment_id='s',scene_id='s',split='train',order=i)
            for i,t in enumerate(['前面的剑。','长'*70,'后面的桥。','又一段。'])]
        ss=core.make_samples(ps,dict(max_source_chars=32,max_target_chars=16,
            source_goal_chars=20,target_goal_chars=6,min_source_chars=1,min_target_chars=1))
        self.assertTrue(ss)
        for s in ss:
            ids=s['source_paragraph_ids']+s['target_paragraph_ids']
            self.assertFalse('0' in ids and '2' in ids)
            self.assertLessEqual(len(s['source']),32)
            self.assertLessEqual(len(s['target']),16)

    def test_duplicate_connected_components_never_cross_splits(self):
        chapters=[dict(chapter_id=f'c{i}',book_id='b',characters=1000,source_group='jinyong') for i in range(40)]
        assignment=core.assign_splits(chapters,[('c1','c2'),('c2','c3')],20261107,.05)
        self.assertEqual(len(assignment),40)
        self.assertEqual(len({assignment[x] for x in ['c1','c2','c3']}),1)
        self.assertIn('validation',set(assignment.values()))
        self.assertEqual(assignment,core.assign_splits(chapters,[('c1','c2'),('c2','c3')],20261107,.05))

    def test_long_substring_detection_survives_reflow_and_prefix_shift(self):
        shared=''.join(chr(0x4e00+i) for i in range(180))
        matches=core.find_exact_edges([dict(segment_id='a',chapter_id='c1',text='开头'+shared+'结尾'),
            dict(segment_id='b',chapter_id='c2',text='另一个开头'+shared[:50]+'\n\n'+shared[50:]+'另结尾')],128)
        self.assertTrue(any({m['chapter_a'],m['chapter_b']}=={'c1','c2'} and m['length']>=180 for m in matches))

    def test_unicode_and_punctuation_are_preserved(self):
        self.assertEqual(core.layout_text('　　他道：“千捧妆盒。。／”　'),'他道：“千捧妆盒。。／”')
        self.assertTrue(core.is_pua('\ue123'))
        self.assertFalse(core.is_pua('𠀀'))
        with self.assertRaises(UnicodeDecodeError):core.decode_strict(b'\xff','utf-8')
        self.assertEqual(core.chapter_number('一○'),10)
        self.assertEqual(core.chapter_number('一百十九'),119)
        self.assertEqual(core.chinese_number(120),'一百二十')

if __name__=='__main__':unittest.main()
