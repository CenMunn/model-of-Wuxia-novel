"""Independent replay gates for source repairs and split-specific sample copies."""
import re
from pipeline_core import is_pua
TABLE=str.maketrans({'著':'着','裡':'里','裏':'里','「':'“','」':'”','『':'‘','』':'’'})
def norm(s):return s.translate(TABLE)

def verify_repair_evidence(repair,witness):
    before=repair['before'];operation=repair['operation']
    if operation=='replace_corrupted_suffix_from_matched_chapter_paragraph':
        p=repair['witness_paragraph'];a=repair['local_suffix_start'];b=repair['witness_suffix_start'];anchor=repair['matching_anchor']
        assert p in witness.split('\n\n')
        assert before.strip()[a-len(anchor):a]==anchor and len(anchor)>=25
        assert norm(p[b-len(anchor):b])==norm(anchor)
        assert len(list(re.finditer(re.escape(norm(anchor)),norm(witness))))==1
        first=next(i for i,c in enumerate(before.strip()) if is_pua(c));assert 0<=first-a<12
        expected=before.strip()[:a]+p[b:]
    elif operation=='complete_explicitly_missing_chapter_tail':
        marker='（以下缺失）';assert before.endswith(marker)
        prefix=before[:-len(marker)];anchor=repair['matching_anchor'];end=repair['witness_suffix_start']
        assert prefix.endswith(anchor) and len(anchor)==40
        hits=list(re.finditer(re.escape(norm(anchor)),norm(witness)));assert len(hits)==1 and hits[0].end()==end
        assert witness[end:].startswith('是个堆书籍之所') and witness.rstrip().endswith('且听下回分解。')
        expected=prefix.strip()+witness[end:]
    elif operation=='replace_pua_from_unique_bilateral_context_in_same_chapter':
        replacements=repair['replacements'];positions=[r['offset'] for r in replacements]
        assert len(set(positions))==len(positions)
        assert set(positions)=={i for i,c in enumerate(before) if is_pua(c)}
        for r in replacements:
            pos=r['offset'];left=r['left_anchor'];right=r['right_anchor'];a=r['witness_start'];b=r['witness_end']
            assert before[pos]==r['before'] and is_pua(before[pos])
            assert len(left)>=8 and len(right)>=8 and before[pos-len(left):pos]==left and before[pos+1:pos+1+len(right)]==right
            assert witness[a:b]==r['after'] and 1<=b-a<=4
            hits=list(re.finditer(re.escape(norm(left))+r'([^\n]{1,4}?)'+re.escape(norm(right)),norm(witness)))
            assert len(hits)==1 and hits[0].span(1)==(a,b)
        expected=before
        for r in sorted(replacements,key=lambda r:r['offset'],reverse=True):
            pos=r['offset'];expected=expected[:pos]+r['after']+expected[pos+1:]
        expected=expected.strip()
    else:raise AssertionError('Unknown repair operation: '+operation)
    assert repair['after']==expected,'After-text is not the exact evidence-backed reconstruction'
    return True

def verify_subset(subset,all_samples,group):
    expected={s['sample_id']:s for s in all_samples if s['source_group']==group}
    ids=[s['sample_id'] for s in subset]
    assert len(ids)==len(set(ids)) and set(ids)==set(expected)
    assert all(s==expected[s['sample_id']] for s in subset),'Subset content differs from the verified full split'
    return True
