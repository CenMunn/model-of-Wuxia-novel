"""Publish only a verified data directory; do not run model training."""
from pathlib import Path
import json,hashlib,platform,subprocess
import numpy
HERE=Path(__file__).resolve().parent
def main():
    config=json.loads((HERE/'config.json').read_text(encoding='utf-8'))
    final=Path(config['output_root']);stage=final.with_name(final.name+'.staging')
    assert stage.exists() and not final.exists()
    v=json.loads((stage/'verification.json').read_text(encoding='utf-8'));assert v['passed']
    assert v['repair_records_replayed_against_cached_source']==33 and v['all_split_subset_objects_verified']
    pointer=final.parent/'current.json';assert not pointer.exists(),'Do not overwrite a shared version pointer'
    assert (HERE/'review_resolution.json').exists(),'Resolve independent review before finalizing'
    review=json.loads((HERE/'review_resolution.json').read_text(encoding='utf-8'));assert review['important_unresolved']==0
    stat=json.loads((stage/'statistics.json').read_text(encoding='utf-8'))
    tools={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.glob('*.py')}
    runtime={'python':platform.python_version(),'numpy':numpy.__version__,'code_sha256':tools}
    (HERE/'runtime_and_code.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[f"# 武侠小说语料预处理版本 {config['version_id']}",'',
        f"已完成17本原始文本的预处理与全量样本核验。正文共 {stat['story_han_characters']:,} 个汉字（含有据补齐的文本，不含目录、序跋、附录及隔离段落）。",
        f"共 {stat['chapters']} 个正文单元、{stat['paragraphs']:,} 个段落；训练 {stat['sample_counts']['train']:,} 条续写样本，验证 {stat['sample_counts']['validation']:,} 条。",
        f"按整回固定划分，验证正文字符比例 {stat['validation_character_fraction']:.2%}。原文测试集未另设，验证结果不得称为独立测试成绩。",'',
        '## 使用路径','',
        '`samples/train_jinyong.jsonl`：仅金庸基线训练；`samples/validation_jinyong.jsonl`：金庸验证。',
        '`samples/train_supplementary.jsonl`：补充语料训练；`samples/validation_supplementary.jsonl`：补充语料验证。',
        '`samples/train.jsonl`、`samples/validation.jsonl`：按来源标签保留的全集；文件行数比例不是既定采样比例。',
        '`clean/chapters.jsonl`、`clean/paragraphs.jsonl`、`clean/segments.jsonl`：章节、段落、连续片段及原文位置。',
        '`reading_only/*.txt`：供人阅读和核查；含回目及显式隔离断点提示，**不得直接拼成训练流**。训练读取上述样本或按连续片段构造。',
        '`records/`：分类、排除、修复、隔离、场景/断点和对照来源；`dedup/`：重复审查及章节分组；`splits/chapters.jsonl`：固定划分。',
        '`vocab/char_all_training.json`：两类训练正文字符词表；`vocab/char_jinyong_training.json`：仅金庸训练正文词表。两个词表均未读取验证集构建。',
        '算法比较使用同一词表；补充语料对比要控制词表与训练预算。若采用仅金庸词表，应报告补充语料的未知字符率。','',
        '## 文本与修复','',
        '金庸按GB18030严格解码，补充文本按UTF-8严格解码；原始字节均未修改。正文副本输出UTF-8。',
        '保留叙事性缘起、诗词、对白、虚词、标点及正常古语；不全局繁简转换，不批量改错别字，不统一删除“。。”或“／”。',
        f"原有196次私用区字符：170次通过同回对照文本恢复，26次随16个无法核实的原段落隔离。共{stat['repair_records']}条修复记录（含第四十五回缺文补齐）。",
        '三侠五义第208、305、323、386行按同段长锚点恢复受损后缀，保留可读前缀；第四十五回从缺文前40字符唯一锚点补至同回末，共1639字符。',
        '儿女英雄传28行按同回、左右各至少8字符的唯一锚点恢复私用区内容；其余16行保留原文并隔离，训练不跨缺口。',
        '对照为维基文库同回文本的简体显示版本。URL、固定修订链接及网页/提取文本指纹保存在records/witness_sources.json；完整缓存存于独立处理工具目录。不同底本仍可能存在字词差异，恢复不等于完成权威校勘。',
        '同一私用区码位在不同位置可对应不同字（如U+E486分别对应“谶”“蜡”），因此没有建立全书通用码位替换表。','',
        '## 章节、重复与样本','',
        '章节保留原回目并统一显示为中文“第X回”；三篇原本没有章回标题的短篇保留正文单元，不捏造回目。雪山飞狐按原文一至一○识别为10回；儿女英雄传缘起单列。',
        f"保留正文中的{stat['scene_breaks_preserved']}处场景分隔，隔离缺口、场景及明确注释边界均阻断续写窗口。",
        f"长片段完全重复阈值128个非空白字符；长段落采用至少100个字母数字字符，MinHash64/16×4 LSH产生近重复候选，字符5-gram Jaccard≥0.85且长度比≥0.8才记录。重复不跨训练/验证章节分组。",
        '常用短语和正常文学重复未自动删改；检出的长重复保留在同一集合。近重复检查限于上述候选算法，不能声称覆盖所有语义改写或短片段。',
        '样本先按整回/重复组划分，再在同回、同连续片段、同场景内选取紧邻完整段落。每个段落边界尝试一次；输入目标约384字符、上限1024字符，输出目标约192字符、上限768字符。',
        '字符长度包括段落间双换行；BOS/EOS等特殊token另计。输入至少64字符、输出至少32字符。超过上限的单段保留在正文，样本生成不跨过它拼接两侧；padding与批量大小留给训练代码。',
        '验证段落的切片可在验证集内部重叠，不能把这些重叠样本当作独立统计重复实验。所有模型复用本版本划分。','',
        '## 按书统计','',
        '|小说|正文单元|汉字|验证回数|验证字符比例|','|---|---:|---:|---:|---:|']
    lines += [f"|{b['title']}|{b['chapters']}|{b['han_characters']:,}|{b['validation_chapters']}|{b['validation_fraction']:.2%}|" for b in stat['books']]
    lines += ['', '## 核验与复现','',
        f"全量核验 {v['samples_verified']:,} 条样本：书、回、集合、连续片段与场景一致；输入/输出均可由原段落精确重建；跨断点、跨回、跨集合重复组均为0。",
        f"验证集未知字符占比 {v['validation_unknown_char_fraction']:.4%}。这是使用训练词表后的覆盖指标，不是模型结果。",
        'verification.json为全量核验记录，raw_manifest.json绑定原件指纹，config.json固定参数。',
        f"处理实现、单元测试、执行日志、源网页缓存与复核记录在 `{config['tools_root']}`，与工程区分开保存。",
        f"复核本版本：`python3 {config['tools_root']}/verify_corpus.py {final}`。重建时必须改用新的版本目录，脚本拒绝覆盖既有版本。",'',
        '## 当前范围与限制','',
        '本版本只完成数据预处理，未开始模型训练、模型评分或最终作品生成。补充采样比例未预设，须与仅金庸基线在相同预算下比较。',
        '未做全书逐字校勘；原文普通疑似错字及未经版本证实的标点保留。16段隔离文本可在之后找到可靠依据时修复并发布新版本。',
        '最终生成评测开头、解码规则、种子和三人独立评分须在最终比较前固定；模型原始输出、人工评分与人工修订作品分别保存。','']
    (stage/'README.md').write_text('\n'.join(lines),encoding='utf-8')
    manifest=json.loads((stage/'manifest.json').read_text(encoding='utf-8'))
    manifest.update(training_ready=True,status='verified_preprocessed_version',verification_file='verification.json',
        code_sha256=tools,python=platform.python_version(),numpy=numpy.__version__)
    (stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    stage.rename(final)
    with pointer.open('x',encoding='utf-8') as f:
        f.write(json.dumps(dict(version_id=config['version_id'],path=str(final),training_ready=True),ensure_ascii=False,indent=2)+'\n')
    (HERE/'run_state.json').write_text(json.dumps(dict(phase='published',final_path=str(final),training_ready=True,training_started=False),ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(finalized=True,path=str(final),training_ready=True,statistics=stat),ensure_ascii=False),flush=True)
if __name__=='__main__':main()
