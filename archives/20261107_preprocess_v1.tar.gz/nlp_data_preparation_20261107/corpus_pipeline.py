"""Build a new literary corpus version without changing any source bytes."""
from pathlib import Path
from collections import Counter,defaultdict
import json,re,hashlib,sys,time,shutil,itertools
from pipeline_core import (layout_text,is_pua,decode_strict,chapter_number,chinese_number,
    make_samples,find_exact_edges,connected_groups,fingerprint_text)
from near_duplicates import find_near_pairs,normalized

HERE=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
def dump(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def jsonl(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8',newline='\n') as f:
        for row in rows:f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
def han_count(s):return sum('\u3400'<=c<='\u9fff' or 0x20000<=ord(c)<=0x323af for c in s)

NUMBERED=re.compile(r'^第([〇○零一二三四五六七八九十百千两0-9]+)[回章](?:[ \t\u3000]+|$)(.*)$')
BARE=re.compile(r'^([〇○零一二三四五六七八九十百千两]+)[ \t\u3000]+(.+)$')

def get_heading(text,spec):
    style=spec['chapter_style']
    if spec.get('narrative_prologue') and text.startswith('缘起首回'):
        return 0,text[len('缘起首回'):].strip(),'缘起首回',True
    m=NUMBERED.fullmatch(text) if style=='numbered' else BARE.fullmatch(text) if style=='bare_title' else None
    if m:
        n=chapter_number(m[1]);return n,m[2].strip(),'第'+chinese_number(n)+'回',False
    if style=='bare_number' and re.fullmatch('[〇○零一二三四五六七八九十]+',text):
        n=chapter_number(text);return n,'','第'+chinese_number(n)+'回',False
    return None

def parse_book(spec,lines,repair_lookup,quarantine_lookup):
    paragraphs=[];chapters=[];boundaries=[];excluded=[];classification=[];punctuation=[]
    current=None;segment_no=scene_no=1;last_blank=0;note_depth=0;supp_note=False
    def record_excluded(start,end,kind,text):
        excluded.append(dict(book_id=spec['book_id'],category=kind,original_line_start=start,
            original_line_end=end,original_text=text,raw_file=spec['relative_path']))
    def new_chapter(n,title,display,original,line,prologue=False):
        nonlocal current,segment_no,scene_no
        if current:current['original_line_end']=line-1
        cid=spec['book_id']+('-prologue' if prologue else '-body' if n is None else f'-c{n:03d}')
        current=dict(book_id=spec['book_id'],book_title=spec['title'],source_group=spec['source_group'],
            chapter_id=cid,number=n,original_title=original,normalized_title=display+((' '+title) if title else ''),
            title=title,is_narrative_prologue=prologue,has_original_heading=original is not None,
            original_line_start=line,original_line_end=None,paragraph_ids=[],blocks=[])
        chapters.append(current);segment_no=scene_no=1
    def boundary(kind,line,text,extra=None):
        nonlocal segment_no,scene_no
        row=dict(boundary_id=f"{spec['book_id']}-L{line:06d}-{kind}",book_id=spec['book_id'],
            chapter_id=current['chapter_id'] if current else None,kind=kind,original_line=line,original_text=text)
        if extra:row.update(extra)
        boundaries.append(row)
        if current:current['blocks'].append(dict(kind=kind,boundary_id=row['boundary_id'],original_line=line))
        segment_no+=1
        if kind=='scene_break':scene_no+=1
    def add_paragraph(text,line,repair=None,part=0):
        nonlocal last_blank
        assert current is not None,(spec['title'],line,text[:80])
        assert not any(map(is_pua,text)),(spec['title'],line)
        p=dict(paragraph_id=f"{spec['book_id']}-L{line:06d}-p{part:02d}",book_id=spec['book_id'],
            source_group=spec['source_group'],chapter_id=current['chapter_id'],
            segment_id=current['chapter_id']+f'-s{segment_no:03d}',scene_id=current['chapter_id']+f'-scene{scene_no:03d}',
            order=len(paragraphs),text=text,original_line_start=line,original_line_end=line,
            raw_file=spec['relative_path'],blank_lines_before=last_blank,
            text_origin='witness_repair' if repair else 'original',repair_id=repair['repair_id'] if repair else None)
        if not repair:
            raw=lines[line-1];start=raw.find(text)
            assert start>=0
            p['original_char_start']=start;p['original_char_end']=start+len(text)
        paragraphs.append(p);current['paragraph_ids'].append(p['paragraph_id'])
        current['blocks'].append(dict(kind='paragraph',paragraph_id=p['paragraph_id']))
        last_blank=0
    if spec['chapter_style']=='unnumbered':
        new_chapter(None,'','正文（原文无章回标题）',None,spec['body_start'])
    for line,raw in enumerate(lines,1):
        text=layout_text(raw)
        if line<spec['body_start']:
            if spec['book_id']=='sanxiawuyi':kind='table_of_contents' if line>=7 else 'website_and_bibliography'
            elif spec['book_id']=='ernvyingxiongzhuan':kind='table_of_contents' if line>=17 else 'preface' if line>=7 else 'bibliography'
            elif spec['book_id']=='jy_tianlong' and line>=32:kind='title_explanation'
            else:kind='shared_preface' if spec['body_start']>3 else 'book_title'
            record_excluded(line,line,kind,raw);classification.append((line,kind,None));continue
        if line>spec['body_end']:
            if spec['source_group']=='supplementary':kind='website_footer' if spec['book_id']=='sanxiawuyi' else 'end_marker_and_trailing_layout'
            elif text.startswith('（全书完') or text=='（完）':kind='end_marker'
            else:kind='appendix_or_afterword'
            record_excluded(line,line,kind,raw);classification.append((line,kind,None));continue
        heading=get_heading(text,spec)
        if heading:
            assert note_depth==0,(spec['title'],line,'unclosed_note')
            supp_note=False
            n,title,display,prologue=heading;new_chapter(n,title,display,text,line,prologue)
            classification.append((line,'chapter_heading',current['chapter_id']));continue
        cid=current['chapter_id'] if current else None
        if supp_note:
            record_excluded(line,line,'chapter_end_glossary',raw);classification.append((line,'annotation',cid));continue
        if spec['book_id']=='sanxiawuyi' and re.match(r'^注[解释]\s*[：:]',text):
            supp_note=True;boundary('annotation_boundary',line,raw)
            record_excluded(line,line,'chapter_end_glossary',raw);classification.append((line,'annotation',cid));continue
        if note_depth or re.match(r'^『注[：:]',text):
            if not note_depth:boundary('annotation_boundary',line,raw)
            note_depth+=raw.count('『')-raw.count('』')
            assert note_depth>=0,(spec['title'],line,'note_depth')
            record_excluded(line,line,'editorial_annotation',raw);classification.append((line,'annotation',cid));continue
        if not text:
            last_blank+=1;classification.append((line,'blank_layout',cid));continue
        if re.fullmatch(r'※(?:\s*※)+',text):
            boundary('scene_break',line,raw);classification.append((line,'scene_break',cid));continue
        issue=quarantine_lookup.get((spec['book_id'],line))
        if issue:
            boundary('quarantine_gap',line,raw,{'quarantine_id':issue['quarantine_id']})
            classification.append((line,'quarantine',cid));continue
        repair=repair_lookup.get((spec['book_id'],line))
        if repair:
            assert raw==repair['before'],(spec['title'],line,'repair_before_mismatch')
            for part,p in enumerate(repair['after'].split('\n\n')):
                if layout_text(p):add_paragraph(layout_text(p),line,repair,part)
            classification.append((line,'repaired_story',cid));continue
        if any(map(is_pua,text)) or '\ufffd' in text or '以下缺失' in text:
            raise AssertionError(('Unaccounted damaged text',spec['title'],line))
        add_paragraph(text,line)
        if any(p in text for p in ['。。','，。','／']):
            punctuation.append(dict(book_id=spec['book_id'],original_line=line,text=text,action='retained_without_version_evidence'))
        classification.append((line,'story',cid))
    assert note_depth==0,(spec['title'],'unclosed_note')
    assert current is not None
    current['original_line_end']=spec['body_end']
    assert len(chapters)==spec['expected_chapters'],(spec['title'],len(chapters),spec['expected_chapters'])
    numbered=[c['number'] for c in chapters if c['number'] not in (None,0)]
    if numbered:assert numbered==list(range(1,max(numbered)+1)),(spec['title'],numbered)
    assert len(classification)==len(lines)
    counts=Counter()
    for p in paragraphs:counts[p['chapter_id']]+=len(p['text'])
    for c in chapters:c['characters']=counts[c['chapter_id']];assert c['characters']>0
    # Compress adjacent excluded lines of the same type while retaining their exact original text.
    compressed=[]
    for row in excluded:
        if compressed and compressed[-1]['category']==row['category'] and compressed[-1]['original_line_end']+1==row['original_line_start']:
            compressed[-1]['original_line_end']=row['original_line_end'];compressed[-1]['original_text']+='\n'+row['original_text']
        else:compressed.append(row)
    ranges=[]
    for line,kind,cid in classification:
        if ranges and (ranges[-1]['category'],ranges[-1]['chapter_id'])==(kind,cid) and ranges[-1]['end_line']+1==line:ranges[-1]['end_line']=line
        else:ranges.append(dict(book_id=spec['book_id'],start_line=line,end_line=line,category=kind,chapter_id=cid))
    return paragraphs,chapters,boundaries,compressed,ranges,punctuation

def main():
    started=time.monotonic();config=json.loads((HERE/'config.json').read_text(encoding='utf-8'))
    root=Path(config['project_root']);out=Path(config['output_root']);stage=out.with_name(out.name+'.staging')
    assert out.parent.resolve()==(root/'shared/data/versions').resolve()
    assert not out.exists() and not stage.exists(),'Refusing to overwrite a data version'
    original_manifest=[];raw_lines={}
    for b in config['books']:
        path=root/b['relative_path'];data=path.read_bytes();assert sha(data)==b['sha256'],str(path)
        lines=decode_strict(data,b['encoding']).splitlines();raw_lines[b['book_id']]=lines
        original_manifest.append(dict(b,bytes=len(data),lines=len(lines)))
    archive=root/config['archive']['relative_path'];assert sha(archive.read_bytes())==config['archive']['sha256']
    witnesses=json.loads((HERE/'witnesses/manifest.json').read_text(encoding='utf-8'))
    for w in witnesses:
        assert 'error' not in w,w
        assert sha((HERE/'witnesses'/w['text_file']).read_bytes())==w['text_sha256']
        assert sha((HERE/'witnesses'/(Path(w['text_file']).stem+'.html')).read_bytes())==w['html_sha256']
    repair_data=json.loads((HERE/'repairs.json').read_text(encoding='utf-8'))
    repairs=repair_data['repairs'];quarantines=repair_data['quarantines']
    for n,r in enumerate(repairs,1):r['repair_id']=f'repair-{n:03d}'
    for n,q in enumerate(quarantines,1):q['quarantine_id']=f'quarantine-{n:03d}'
    lookup={(r['book_id'],r['line']):r for r in repairs};ql={(q['book_id'],q['line']):q for q in quarantines}
    assert len(lookup)==len(repairs) and not set(lookup)&set(ql)
    original_pua=sum(sum(map(is_pua,s)) for lines in raw_lines.values() for s in lines)
    assert original_pua==sum(r['original_pua_occurrences'] for r in repairs)+sum(q['original_pua_occurrences'] for q in quarantines)==196
    allp=[];allc=[];allb=[];alle=[];allr=[];allpun=[]
    for b in config['books']:
        ps,cs,bs,es,rs,puns=parse_book(b,raw_lines[b['book_id']],lookup,ql)
        allp.extend(ps);allc.extend(cs);allb.extend(bs);alle.extend(es);allr.extend(rs);allpun.extend(puns)
        print('Parsed',b['title'],len(cs),'chapters',len(ps),'paragraphs',flush=True)
    segments=[]
    for sid,group in itertools.groupby(allp,key=lambda p:p['segment_id']):
        ps=list(group);segments.append(dict(segment_id=sid,chapter_id=ps[0]['chapter_id'],book_id=ps[0]['book_id'],
            source_group=ps[0]['source_group'],paragraph_ids=[p['paragraph_id'] for p in ps],text='\n\n'.join(p['text'] for p in ps)))
    print('Scanning exact substrings...',flush=True)
    exact=find_exact_edges(segments,config['dedup']['exact_substring_min_chars'])
    exact_paras=[];seen=defaultdict(list)
    for p in allp:
        t=normalized(p['text'])
        if len(t)<config['dedup']['paragraph_min_alnum_chars']:continue
        key=sha(t.encode())
        for prev in seen[key]:
            if prev['chapter_id']!=p['chapter_id']:
                exact_paras.append(dict(type='exact_alnum_paragraph',chapter_a=prev['chapter_id'],chapter_b=p['chapter_id'],
                    paragraph_a=prev['paragraph_id'],paragraph_b=p['paragraph_id'],characters=len(t)))
        seen[key].append(p)
    print('Scanning near-duplicate paragraphs...',flush=True)
    near=find_near_pairs(allp,config['dedup']['near_jaccard_threshold'],config['dedup']['paragraph_min_alnum_chars'],config['dedup']['near_min_length_ratio'])
    edges=[(r['chapter_a'],r['chapter_b']) for r in exact+exact_paras+near]
    groups=connected_groups([c['chapter_id'] for c in allc],edges)
    group_of={i:gid for gid,ids in groups.items() for i in ids}
    from pipeline_core import assign_splits
    assignment=assign_splits(allc,edges,config['split']['seed'],config['split']['validation_target_character_fraction'])
    for c in allc:c['split']=assignment[c['chapter_id']];c['duplicate_group_id']=group_of[c['chapter_id']]
    for p in allp:p['split']=assignment[p['chapter_id']]
    for s in segments:s['split']=assignment[s['chapter_id']]
    assert all(assignment[a]==assignment[b] for a,b in edges)
    print('Constructing paragraph continuations...',flush=True)
    samples=make_samples(allp,config['samples'])
    vocab_chars=Counter(c for p in allp if p['split']=='train' for c in p['text'])
    vocab_chars['\n']+=sum(p['split']=='train' for p in allp)*2
    jinchars=Counter(c for p in allp if p['split']=='train' and p['source_group']=='jinyong' for c in p['text'])
    jinchars['\n']+=sum(p['split']=='train' and p['source_group']=='jinyong' for p in allp)*2
    stage.mkdir(parents=True)
    dump(stage/'config.json',config);dump(stage/'raw_manifest.json',{'books':original_manifest,'archive':config['archive']})
    jsonl(stage/'clean/paragraphs.jsonl',allp);jsonl(stage/'clean/chapters.jsonl',allc);jsonl(stage/'clean/segments.jsonl',segments)
    for name,rows in [('repairs',repairs),('quarantine',quarantines),('boundaries',allb),('excluded_blocks',alle),('line_classification',allr),('punctuation_candidates_retained',allpun)]:
        jsonl(stage/f'records/{name}.jsonl',rows)
    dump(stage/'records/witness_sources.json',witnesses)
    jsonl(stage/'dedup/exact_substrings.jsonl',exact);jsonl(stage/'dedup/exact_paragraphs.jsonl',exact_paras);jsonl(stage/'dedup/near_paragraphs.jsonl',near)
    jsonl(stage/'dedup/chapter_components.jsonl',[dict(duplicate_group_id=g,chapter_ids=ids,split=assignment[ids[0]]) for g,ids in sorted(groups.items())])
    jsonl(stage/'splits/chapters.jsonl',[{k:c[k] for k in ['book_id','chapter_id','source_group','characters','duplicate_group_id','split']} for c in allc])
    for split in ['train','validation']:
        jsonl(stage/f'samples/{split}.jsonl',(s for s in samples if s['split']==split))
        for group in ['jinyong','supplementary']:
            jsonl(stage/f'samples/{split}_{group}.jsonl',(s for s in samples if s['split']==split and s['source_group']==group))
    for name,chars in [('char_all_training',vocab_chars),('char_jinyong_training',jinchars)]:
        dump(stage/f'vocab/{name}.json',dict(special_tokens=['<pad>','<unk>','<bos>','<eos>'],
            tokens=['<pad>','<unk>','<bos>','<eos>']+sorted(chars),counts=dict(sorted(chars.items())),
            trained_from='train paragraphs only; no validation characters counted',normalization='none'))
    pmap={p['paragraph_id']:p for p in allp}
    for b in config['books']:
        content=[]
        for c in allc:
            if c['book_id']!=b['book_id']:continue
            content.append(c['normalized_title'])
            for block in c['blocks']:
                if block['kind']=='paragraph':content.append(pmap[block['paragraph_id']]['text'])
                elif block['kind']=='scene_break':content.append('※※※')
                elif block['kind']=='quarantine_gap':content.append('〔受损段落隔离断点：'+block['boundary_id']+'〕')
        path=stage/f"reading_only/{b['title']}.txt";path.parent.mkdir(exist_ok=True)
        path.write_text('\n\n'.join(content)+'\n',encoding='utf-8')
    books=[]
    for b in config['books']:
        ps=[p for p in allp if p['book_id']==b['book_id']];cs=[c for c in allc if c['book_id']==b['book_id']]
        chars=sum(len(p['text']) for p in ps);val=sum(len(p['text']) for p in ps if p['split']=='validation')
        books.append(dict(book_id=b['book_id'],title=b['title'],source_group=b['source_group'],chapters=len(cs),
            paragraphs=len(ps),characters=chars,han_characters=sum(han_count(p['text']) for p in ps),validation_characters=val,
            validation_fraction=val/chars,validation_chapters=sum(c['split']=='validation' for c in cs)))
    summary=dict(version_id=config['version_id'],books=books,logical_books=len(books),chapters=len(allc),paragraphs=len(allp),
        story_characters=sum(b['characters'] for b in books),story_han_characters=sum(b['han_characters'] for b in books),
        chapter_split_counts=dict(Counter(c['split'] for c in allc)),sample_counts=dict(Counter(s['split'] for s in samples)),
        sample_counts_by_source=dict(Counter(s['split']+'_'+s['source_group'] for s in samples)),
        validation_character_fraction=sum(b['validation_characters'] for b in books)/sum(b['characters'] for b in books),
        pua_original=original_pua,pua_repaired=sum(r['original_pua_occurrences'] for r in repairs),
        pua_quarantined=sum(q['original_pua_occurrences'] for q in quarantines),repair_records=len(repairs),quarantine_paragraphs=len(quarantines),
        restored_missing_tail_characters=sum(r.get('inserted_characters',0) for r in repairs),
        scene_breaks_preserved=sum(b['kind']=='scene_break' for b in allb),
        exact_cross_chapter_edges=len(exact),exact_paragraph_pairs=len(exact_paras),near_paragraph_pairs=len(near),
        duplicate_components_multiple_chapters=sum(len(g)>1 for g in groups.values()),
        whole_paragraphs_over_target_cap=sum(len(p['text'])>config['samples']['max_target_chars'] for p in allp),
        vocab_types_including_specials=len(vocab_chars)+4,independent_source_test_set=False,training_started=False,
        supplemental_mix_ratio=None,elapsed_seconds=round(time.monotonic()-started,2))
    dump(stage/'statistics.json',summary)
    dump(stage/'manifest.json',dict(version_id=config['version_id'],training_ready=False,status='awaiting_independent_validation',
        code_directory=config['tools_root'],raw_files_unchanged=True,independent_source_test_set=False,
        supplemental_mix_ratio=None,limitations=['未做全文逐字校勘','近重复为LSH候选加阈值审查，不代表所有语义改写均被发现','16处无法核实的原段落被隔离','验证集用于调参，不是独立测试集']))
    print('BUILD_COMPLETE',json.dumps(summary,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
